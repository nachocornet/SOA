/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>
#include <hardware.h>

char initial_stack[KERNEL_STACK_SIZE]; // Space for the initial system stack

struct list_head readyqueue;
struct list_head blocked;
struct task_struct *init_task;
struct task_struct *idle_task;

int PT_system;
int PT_systemHigh;
page_table_entry *PT_systemAddress;
page_table_entry *PT_systemHighAddress;

static int remaining_ticks;
static int active_tasks;
static struct task_struct *pending_reap;

extern void writeMSR(unsigned int msr_number, unsigned int value);
extern void task_switch(union task_union *new);
extern void switch_stack(int *save_ebp, int *new_esp);

struct task_struct *alloc_task_struct(void)
{
	if (PT_systemAddress == NULL) return NULL;

	int pcb_frame = alloc_frame();
	if (pcb_frame == -1) return NULL;

	map_system_frame(pcb_frame);
	
	// Hacer flush TLB solo si ya está la paginación activada
	if (read_cr0() & 0x80000000) set_cr3(current()->dir_pages_baseAddr);

	union task_union *tu = (union task_union *)system_frame_to_address(pcb_frame);
	for (int i = 0; i < KERNEL_STACK_SIZE; ++i) tu->stack[i] = 0;

	tu->task.PID = -1;
	tu->task.dir_pages_baseAddr = NULL;
	INIT_LIST_HEAD(&tu->task.list);
	INIT_LIST_HEAD(&tu->task.children);
	INIT_LIST_HEAD(&tu->task.sibling);
	tu->task.parent = NULL;
	tu->task.kernel_esp = 0;
	tu->task.quantum = 0;
	tu->task.pending_unblocks = 0;
	for (int i = 0; i < SHM_MAX_PAGES; ++i) tu->task.shm_addr[i] = -1;
	tu->task.state = ST_FREE;

	active_tasks++;
	return &tu->task;
}

void free_task_struct(struct task_struct *t)
{
	if (t == NULL) return;

	unsigned int pcb_frame = system_address_to_frame(t);
	if (PT_systemAddress != NULL) {
		unmap_system_frame(pcb_frame);
		if (read_cr0() & 0x80000000) set_cr3(current()->dir_pages_baseAddr);
	}
	free_frame(pcb_frame);
	if (active_tasks > 0) active_tasks--;
}

void defer_free_current_task(struct task_struct *t)
{
	if (pending_reap != NULL) {
		free_task_struct(pending_reap);
	}
	pending_reap = t;
}

void reap_terminated_tasks(void)
{
	if (pending_reap != NULL && pending_reap != current()) {
		free_task_struct(pending_reap);
		pending_reap = NULL;
	}
}

void allocate_DIR(struct task_struct *t) {
	int Dir = alloc_frame();
	if (Dir == -1)
		return; /* Sin memoria, el llamante debe manejarlo */

	int PT_user = alloc_frame();
	if (PT_user == -1) {
		free_frame(Dir);
		return;
	}

	/* PRIMERO: Mapear los frames en PT_systemAddress ANTES de acceder a ellos */
	map_system_frame(Dir);
	map_system_frame(PT_user);

	/* Mapear el PCB en PT_systemAddress para que sea accesible con cualquier CR3 */
	unsigned int PCB_frame = system_address_to_frame(t);
	map_system_frame(PCB_frame);

	/* FLUSH TLB para asegurar que los nuevos mapeos sean visibles */
	set_cr3(current()->dir_pages_baseAddr);

	/* AHORA podemos acceder a las direcciones virtuales mapeadas */
	page_table_entry *DirAddress = (page_table_entry *) system_frame_to_address(Dir);
	page_table_entry *PT_userAddress = (page_table_entry *) system_frame_to_address(PT_user);

	clear_page_table(DirAddress);
	clear_page_table(PT_userAddress);

	/* Entrada 0: espacio kernel compartido */
	DirAddress[0].entry = 0;
	DirAddress[0].bits.pbase_addr = PT_system;
	DirAddress[0].bits.rw = 1;
	DirAddress[0].bits.present = 1;
	DirAddress[2].entry = 0;
	DirAddress[2].bits.pbase_addr = PT_systemHigh;
	DirAddress[2].bits.rw = 1;
	DirAddress[2].bits.present = 1;

	/* Entrada 1: espacio de usuario del proceso */
	DirAddress[1].entry = 0;
	DirAddress[1].bits.pbase_addr = PT_user;
	DirAddress[1].bits.rw = 1;
	DirAddress[1].bits.present = 1;
	DirAddress[1].bits.user = 1;

	/* Guardar directorio en task_struct */
	t->dir_pages_baseAddr = DirAddress;
}


void cpu_idle(void)
{
	__sti();
	printk("Idle task running...\n");
	while(1)
	{
	}
}

void init_idle (void)
{
	// 1)
	struct task_struct *t = alloc_task_struct();
	if (t == NULL) return;

	int Dir = alloc_frame();
	if (Dir == -1) {
		free_task_struct(t);
		return;
	}

	map_system_frame(Dir);

	page_table_entry *DirAddress = (page_table_entry *) system_frame_to_address(Dir);
	clear_page_table(DirAddress);

	DirAddress[0].entry = 0;
	DirAddress[0].bits.pbase_addr = PT_system;
	DirAddress[0].bits.rw = 1;
	DirAddress[0].bits.present = 1;
	DirAddress[2].entry = 0;
	DirAddress[2].bits.pbase_addr = PT_systemHigh;
	DirAddress[2].bits.rw = 1;
	DirAddress[2].bits.present = 1;

	// 4)
	
	// 2)
	t->dir_pages_baseAddr = DirAddress;

	// 3)
	union task_union *tu = (union task_union *)t;
	tu->stack[KERNEL_STACK_SIZE - 1] = (unsigned long)cpu_idle;
	tu->stack[KERNEL_STACK_SIZE - 2] = 0;
	t->kernel_esp = (int)&(tu->stack[KERNEL_STACK_SIZE - 2]);
	idle_task = t;

	// 5)
	int PCB_frame = ((unsigned int)t) >> 12;
	map_system_frame(PCB_frame);
	
	// 6)
	t->PID = 0;
	t->quantum = 1000;
	t->state = ST_RUN;
	INIT_LIST_HEAD(&t->children);
	INIT_LIST_HEAD(&t->sibling);
	t->parent = NULL;
	t->pending_unblocks = 0;

	/* Idle is the parent of init process. */
	init_task->parent = t;
	list_add_tail(&init_task->sibling, &t->children);
}

void init_task1(void)
{
	// 1a) Allocate a new directory
	int Dir = alloc_frame();
	page_table_entry *DirAddress = (page_table_entry *) system_frame_to_address(Dir);

	// 1b) Initialize all directory entries
	clear_page_table(DirAddress);

	// 1c) Allocate a page table to store system mappings (ONLY ONCE, globally)
	// 1d) Initialize used system pages on this system page table
	if (PT_system == 0) {
		PT_system = alloc_frame();
		PT_systemHigh = alloc_frame();
		if (PT_system == -1 || PT_systemHigh == -1) {
			if (PT_system != -1) free_frame(PT_system);
			if (PT_systemHigh != -1) free_frame(PT_systemHigh);
			free_frame(Dir);
			return;
		}

		PT_systemAddress = (page_table_entry *)system_frame_to_address(PT_system);
		PT_systemHighAddress = (page_table_entry *)system_frame_to_address(PT_systemHigh);
		clear_page_table(PT_systemAddress);
		clear_page_table(PT_systemHighAddress);
		set_kernel_pages(PT_systemAddress);

		/* Keep system page table frames accessible after enabling paging. */
		map_system_frame(PT_system);
		map_system_frame(PT_systemHigh);
	}

	// 1e) Allocate a page table to store user mappings
	int PT_user = alloc_frame();
	map_system_frame(PT_user);
	page_table_entry *PT_userAddress = (page_table_entry *) system_frame_to_address(PT_user);
	clear_page_table(PT_userAddress);

	// 1f) Complete initialization of address space with set_user_pages
	set_user_pages(PT_userAddress);

	// 1g) Map Directory and both page tables in the system page table
	map_system_frame(Dir);
	map_system_frame(PT_user);

	// 1h) Assign System page table to first directory entry
	DirAddress[0].entry = 0;
	DirAddress[0].bits.pbase_addr = PT_system;
	DirAddress[0].bits.rw = 1;
	DirAddress[0].bits.present = 1;
	DirAddress[2].entry = 0;
	DirAddress[2].bits.pbase_addr = PT_systemHigh;
	DirAddress[2].bits.rw = 1;
	DirAddress[2].bits.present = 1;

	// 1i) Assign User page table to second directory entry with user permissions
	DirAddress[1].entry = 0;
	DirAddress[1].bits.pbase_addr = PT_user;
	DirAddress[1].bits.rw = 1;
	DirAddress[1].bits.present = 1;
	DirAddress[1].bits.user = 1;


	// PASO 2: Allocate a new struct task_struct
	struct task_struct *t = alloc_task_struct();
	if (t == NULL) {
		free_frame(PT_user);
		free_frame(Dir);
		return;
	}


	// PASO 3: Map PCB in the system page table
	int PCB_frame = ((unsigned int)t) >> 12;
	map_system_frame(PCB_frame);


	// PASO 4: Assign PID 1 to the process
	t->PID = 1;
	t->quantum = 10;
	remaining_ticks = t->quantum;


	// PASO 5: Update the TSS to point to the new task system stack
	union task_union *tu = (union task_union *)t;
	tss.esp0 = (DWord)&(tu->stack[KERNEL_STACK_SIZE]);
	writeMSR(0x175, tss.esp0);

	// Initialize kernel_esp for use in fork()
	t->kernel_esp = (int)&(tu->stack[KERNEL_STACK_SIZE]);


	// PASO 6: Initialize dir_pages_baseAddr with the new directory
	t->dir_pages_baseAddr = DirAddress;


	// PASO 7: Set its page directory as the current page directory
	set_cr3(t->dir_pages_baseAddr);


	// PASO 8: Define global init_task and initialize it to this init PCB
	init_task = t;
	INIT_LIST_HEAD(&t->children);
	INIT_LIST_HEAD(&t->sibling);
	t->parent = NULL;
	t->pending_unblocks = 0;
	t->state = ST_RUN;

}


void init_sched()
{
    INIT_LIST_HEAD(&readyqueue);
    INIT_LIST_HEAD(&blocked);
	active_tasks = 0;
	pending_reap = NULL;
}

void inner_task_switch(union task_union *new) {
	// 1)
	tss.esp0 = (DWord) &(new->stack[KERNEL_STACK_SIZE]); 
	writeMSR(0x175, (DWord) &(new->stack[KERNEL_STACK_SIZE])); 

	// 2)
	set_cr3(new->task.dir_pages_baseAddr);

	switch_stack(&(current()->kernel_esp), &(new->task.kernel_esp));
}

void update_sched_data_rr(void)
{
	if (current() != idle_task) {
		remaining_ticks--;
	}
}

int needs_sched_rr(void)
{
	if (!list_empty(&readyqueue)) {
		if (current() == idle_task) {
			return 1;
		}
		if (remaining_ticks <= 0) {
			return 1;
		}
	}
	return 0;
}

void update_process_state_rr(struct task_struct *t, struct list_head *dst_queue)
{
    if (t->state != ST_RUN) {
        list_del(&t->list);
    }
    if (dst_queue != NULL) {
        list_add_tail(&t->list, dst_queue);
        if (dst_queue == &readyqueue) t->state = ST_READY;
		else t->state = ST_BLOCKED;
    } else {
        t->state = ST_RUN;
    }
}

void sched_next_rr(void)
{
	if (list_empty(&readyqueue)) {
		return;
	}

	struct task_struct *next = list_head_to_task_struct(list_first(&readyqueue));


	update_process_state_rr(next, NULL);
	remaining_ticks = get_quantum(next);
	task_switch((union task_union *) next);
}

void schedule(void)
{
	reap_terminated_tasks();

	update_sched_data_rr();

	if (!needs_sched_rr()) {
		return;
	}

	struct task_struct *cur = current();

	if (cur != idle_task) {
		update_process_state_rr(cur, &readyqueue);
	}

	sched_next_rr();
}


/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t)
{
       return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t)
{
	return (page_table_entry *)system_frame_to_address(t->dir_pages_baseAddr[1].bits.pbase_addr);
}

struct task_struct * list_head_to_task_struct(struct list_head *l) {
	return (struct task_struct *)((unsigned int)l & 0xFFFFF000);
}

int get_quantum(struct task_struct *t) {
    return t->quantum;
}

void set_quantum(struct task_struct *t, int new_quantum) {
    t->quantum = new_quantum;
}
